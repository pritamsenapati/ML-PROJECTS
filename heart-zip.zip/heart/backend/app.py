
import os, joblib, sqlite3, json
from flask import Flask, jsonify, request, send_from_directory
from flask_cors import CORS
import pandas as pd

BASE_DIR = os.path.dirname(__file__)
DB_PATH = os.path.join(BASE_DIR, '..', 'data', 'app.db')
MODEL_PATH = os.path.join(BASE_DIR, 'models', 'model.pkl')
SCALER_PATH = os.path.join(BASE_DIR, 'models', 'scaler.pkl')

app = Flask(__name__, static_folder='../frontend', static_url_path='/')
CORS(app)

# Load model and scaler
model = None
scaler = None
if os.path.exists(MODEL_PATH) and os.path.exists(SCALER_PATH):
    model = joblib.load(MODEL_PATH)
    scaler = joblib.load(SCALER_PATH)
    print("Loaded model and scaler.")
else:
    print("Model or scaler not found. Make sure you trained the model and files placed in backend/models/")

def get_db_conn():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

@app.route('/')
def index():
    return send_from_directory(app.static_folder, 'index.html')

@app.route('/api/data')
def api_data():
    limit = int(request.args.get('limit', 100))
    offset = int(request.args.get('offset', 0))
    conn = get_db_conn()
    rows = conn.execute("SELECT * FROM dataset LIMIT ? OFFSET ?", (limit, offset)).fetchall()
    conn.close()
    return jsonify({'count': len(rows), 'results': [dict(r) for r in rows]})

@app.route('/api/stats')
def api_stats():
    conn = get_db_conn()
    df = pd.read_sql_query("SELECT * FROM dataset", conn)
    conn.close()
    total = len(df)
    numeric = df.select_dtypes(include=['int64','float64']).columns.tolist()
    stats = {}
    for c in numeric:
        stats[c] = {'mean': float(df[c].mean()), 'min': float(df[c].min()), 'max': float(df[c].max())}
    return jsonify({'total_rows': total, 'numeric_stats': stats})

@app.route('/predict', methods=['POST'])
def predict():
    """
    Accepts JSON payload with the following fields:
    age, gender, height, weight, ap_hi, ap_lo, cholesterol, gluc, smoke, alco, active, bmi (optional)
    """
    if model is None or scaler is None:
        return jsonify({'error': 'model not available on server. Train first.'}), 500

    data = request.json
    # required fields
    fields = ['age','gender','height','weight','ap_hi','ap_lo','cholesterol','gluc','smoke','alco','active']
    for f in fields:
        if f not in data:
            return jsonify({'error': f'missing field {f}'}), 400

    # compute bmi if not provided
    if 'bmi' not in data or data['bmi'] is None:
        try:
            bmi = data['weight'] / ((data['height']/100)**2)
        except Exception:
            bmi = 0
        data['bmi'] = round(bmi,2)

    # order features to match training
    feature_order = ['age','gender','height','weight','ap_hi','ap_lo','cholesterol','gluc','smoke','alco','active','bmi']
    X = [[ float(data.get(f, 0)) for f in feature_order ]]

    # scale numeric features (scaler expects same columns)
    import numpy as np
    # We'll assume scaler was fit on the numeric columns in order
    X_scaled = X.copy()
    # convert to DataFrame using feature_order column names temporarily
    import pandas as pd
    Xdf = pd.DataFrame(X, columns=feature_order)
    numeric_cols = Xdf.select_dtypes(include=['number']).columns.tolist()
    Xdf[numeric_cols] = scaler.transform(Xdf[numeric_cols])
    proba = model.predict_proba(Xdf.values)[:,1][0]
    pred = int(model.predict(Xdf.values)[0])
    return jsonify({'prediction': pred, 'probability': float(proba), 'used_features': dict(zip(feature_order, X[0]))})

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)

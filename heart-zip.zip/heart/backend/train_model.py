# backend/train_model.py
import os
import pandas as pd
import joblib
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import roc_auc_score, accuracy_score
from sklearn.pipeline import Pipeline

CSV_PATH = os.path.join(os.path.dirname(__file__), '..', 'data', 'clean_cardio.csv')
MODEL_OUT = os.path.join(os.path.dirname(__file__), 'models', 'model.pkl')
SCALER_OUT = os.path.join(os.path.dirname(__file__), 'models', 'scaler.pkl')

os.makedirs(os.path.join(os.path.dirname(__file__), 'models'), exist_ok=True)

df = pd.read_csv(CSV_PATH)

# Features and target
target = 'cardio'
# drop id and target
X = df.drop(columns=[target, 'id'])
y = df[target]

# One-hot encode categorical small-value columns if needed (gender, cholesterol, gluc, smoke, alco, active)
# For simplicity, treat them as numeric (most are small ints). If you prefer one-hot, add pd.get_dummies

# Split
X_train, X_test, y_train, y_test = train_test_split(X, y, stratify=y, test_size=0.2, random_state=42)

# Scale numeric features
numeric_cols = X_train.select_dtypes(include=['int64','float64']).columns.tolist()
scaler = StandardScaler()
X_train_scaled = X_train.copy()
X_test_scaled = X_test.copy()
X_train_scaled[numeric_cols] = scaler.fit_transform(X_train[numeric_cols])
X_test_scaled[numeric_cols] = scaler.transform(X_test[numeric_cols])

# Candidate models
models = {
    'logistic': LogisticRegression(max_iter=1000, solver='liblinear'),
    'rf': RandomForestClassifier(n_estimators=200, random_state=42, n_jobs=-1)
}

# try xgboost if available
try:
    from xgboost import XGBClassifier
    models['xgb'] = XGBClassifier(use_label_encoder=False, eval_metric='logloss', random_state=42, n_estimators=200, verbosity=0)
except Exception as e:
    print("XGBoost not available or failed to import:", e)

best = None
best_auc = -1
results = {}

for name, m in models.items():
    m.fit(X_train_scaled, y_train)
    probs = m.predict_proba(X_test_scaled)[:,1]
    preds = m.predict(X_test_scaled)
    auc = roc_auc_score(y_test, probs)
    acc = accuracy_score(y_test, preds)
    results[name] = {'auc': auc, 'accuracy': acc}
    print(f"{name}: AUC={auc:.4f}, Acc={acc:.4f}")
    if auc > best_auc:
        best_auc = auc
        best = (name, m)

print("Best model:", best[0], "AUC:", best_auc)

# Save scaler and best model
joblib.dump(scaler, SCALER_OUT)
joblib.dump(best[1], MODEL_OUT)
print("Saved scaler to", SCALER_OUT)
print("Saved model to", MODEL_OUT)

# Optional: write a small JSON of results
import json
with open(os.path.join(os.path.dirname(__file__), 'models', 'train_metrics.json'), 'w') as f:
    json.dump({'results': results, 'best': best[0], 'best_auc': best_auc}, f, indent=2)

const el = id => document.getElementById(id);
// Use absolute API base to avoid relative path issues
const API_BASE = window.location.origin;
const api = { data: `${API_BASE}/api/data`, stats: `${API_BASE}/api/stats`, predict: `${API_BASE}/predict` };

// Embedded fallback sample data (used if backend /api/data fails)
const SAMPLE_DATA = [
    { id: 1, age: 52, gender: 1, height: 170, weight: 72, ap_hi: 130, ap_lo: 85, cholesterol: 1, gluc: 1, smoke: 0, alco: 0, active: 1, bmi: 24.9, cardio: 0 },
    { id: 2, age: 64, gender: 2, height: 160, weight: 80, ap_hi: 140, ap_lo: 90, cholesterol: 3, gluc: 2, smoke: 1, alco: 0, active: 0, bmi: 31.2, cardio: 1 },
    { id: 3, age: 45, gender: 1, height: 175, weight: 78, ap_hi: 135, ap_lo: 88, cholesterol: 2, gluc: 1, smoke: 0, alco: 1, active: 1, bmi: 25.5, cardio: 0 },
    { id: 4, age: 58, gender: 2, height: 162, weight: 68, ap_hi: 145, ap_lo: 95, cholesterol: 3, gluc: 3, smoke: 0, alco: 0, active: 0, bmi: 25.9, cardio: 1 },
    { id: 5, age: 36, gender: 1, height: 180, weight: 76, ap_hi: 120, ap_lo: 78, cholesterol: 1, gluc: 1, smoke: 0, alco: 0, active: 1, bmi: 23.5, cardio: 0 }
];

async function fetchJSON(url, opts) {
    try {
        const r = await fetch(url, opts);
        const text = await r.text();
        if (!r.ok) {
            // Try parse JSON error
            try { const obj = JSON.parse(text); throw new Error(obj.error || JSON.stringify(obj)); } catch (e) {
                // If the response looks like XML (blob errors) show friendly message
                if (text && text.trim().startsWith('<?xml')) {
                    throw new Error('Server returned XML error (possible BlobNotFound or storage error). Check backend logs.');
                }
                throw new Error(text || r.statusText);
            }
        }
        try { return JSON.parse(text); } catch (e) { return text; }
    } catch (e) {
        // Network or CORS error
        throw new Error(`Network or server error: ${e.message}`);
    }
}

// Functions to render UI components
let lastRows = [];
function renderTable(rows) { lastRows = rows; if (!rows || rows.length === 0) { el('tableWrapper').innerHTML = '<div style="padding:12px;color:var(--muted)">No rows</div>'; return } const cols = Object.keys(rows[0]); let html = '<table><thead><tr>' + cols.map(c => `<th>${c}</th>`).join('') + '</tr></thead><tbody>'; html += rows.map(r => '<tr>' + cols.map(c => `<td>${String(r[c]).slice(0, 40)}</td>`).join('') + '</tr>').join(''); html += '</tbody></table>'; el('tableWrapper').innerHTML = html; }

function computeKPIs(rows) { if (!rows || rows.length === 0) return; const total = rows.length; const avgAge = (rows.reduce((s, r) => s + Number(r.age), 0) / total).toFixed(1); const cardioPct = (rows.filter(r => Number(r.cardio) === 1).length / total * 100).toFixed(1) + '%'; el('kpi-age').innerText = avgAge; el('kpi-cardio').innerText = cardioPct; el('kpi-total').innerText = total.toLocaleString(); }

// Charts
let ageChart, bmiChart, cholChart, gaugeChartInstance;
function renderAgeChart(rows) { const buckets = {}; rows.forEach(r => { const a = Math.max(0, Math.min(120, Math.floor(Number(r.age) / 10) * 10)); const k = `${a}-${a + 9}`; if (!buckets[k]) buckets[k] = { total: 0, pos: 0 }; buckets[k].total++; if (Number(r.cardio) === 1) buckets[k].pos++; }); const labels = Object.keys(buckets).sort((a, b) => Number(a.split('-')[0]) - Number(b.split('-')[0])); const vals = labels.map(l => (buckets[l].total ? (buckets[l].pos / buckets[l].total * 100).toFixed(2) : 0)); const ctx = el('ageChart').getContext('2d'); if (ageChart) ageChart.destroy(); ageChart = new Chart(ctx, { type: 'bar', data: { labels, datasets: [{ label: '% with cardio', data: vals }] }, options: { responsive: true } }); }
function renderBMIChart(rows) { const vals = rows.map(r => Number(r.bmi)).filter(v => !isNaN(v)); const bins = [0, 18.5, 25, 30, 35, 100]; const counts = new Array(bins.length - 1).fill(0); vals.forEach(v => { for (let i = 0; i < bins.length - 1; i++) { if (v >= bins[i] && v < bins[i + 1]) { counts[i]++; break } } }); const labels = ['Under18.5', '18.5-24.9', '25-29.9', '30-34.9', '35+']; const ctx = el('bmiChart').getContext('2d'); if (bmiChart) bmiChart.destroy(); bmiChart = new Chart(ctx, { type: 'pie', data: { labels, datasets: [{ data: counts }] }, options: { responsive: true } }); }
function renderCholChart(rows) { const map = { '1': 0, '2': 0, '3': 0 }; rows.forEach(r => { const c = String(r.cholesterol); if (map[c] !== undefined) map[c]++; }); const labels = ['1-normal', '2-above', '3-high']; const data = [map['1'], map['2'], map['3']]; const ctx = el('cholChart').getContext('2d'); if (cholChart) cholChart.destroy(); cholChart = new Chart(ctx, { type: 'doughnut', data: { labels, datasets: [{ data }] }, options: { responsive: true } }); }

function renderGauge(prob) { const ctx = el('gaugeChart').getContext('2d'); if (gaugeChartInstance) gaugeChartInstance.destroy(); const safeProb = Math.max(0, Math.min(1, Number(prob) || 0)); gaugeChartInstance = new Chart(ctx, { type: 'doughnut', data: { labels: ['prob', 'rest'], datasets: [{ data: [safeProb, 1 - safeProb], backgroundColor: [getColorForProb(safeProb), '#e6eef7'], hoverOffset: 0 }] }, options: { cutout: '70%', plugins: { legend: { display: false } }, rotation: -90 * Math.PI / 180, circumference: 180 * Math.PI / 180 } }); }
function getColorForProb(p) { if (p > 0.7) return 'rgba(239,68,68,0.9)'; if (p > 0.4) return 'rgba(250,204,21,0.9)'; return 'rgba(16,185,129,0.9)'; }

// loadData: attempts fetch, on failure shows friendly message and offers sample fallback
async function loadData(limit = 100) {
    const table = el('tableWrapper');
    table.innerHTML = '<div style="padding:12px;color:var(--muted)">Loading...</div>';
    try {
        const url = `${api.data}?limit=${limit}`;
        const j = await fetchJSON(url);
        const rows = j && j.results ? j.results : [];
        if (!rows || rows.length === 0) {
            throw new Error('Received empty results from /api/data');
        }
        renderTable(rows);
        renderAgeChart(rows);
        renderBMIChart(rows);
        renderCholChart(rows);
        computeKPIs(rows);
    } catch (e) {
        console.error('Failed to load data:', e.message);
        table.innerHTML = `<div style="padding:12px;color:var(--danger)">Failed to load data: ${e.message}</div>` +
            `<div style="padding:12px"><button id="useSample" class="btn ghost">Use sample data</button> <button id="retryBtn" class="btn">Retry</button></div>`;
        document.getElementById('retryBtn').addEventListener('click', () => loadData(limit));
        document.getElementById('useSample').addEventListener('click', () => { renderTable(SAMPLE_DATA); renderAgeChart(SAMPLE_DATA); renderBMIChart(SAMPLE_DATA); renderCholChart(SAMPLE_DATA); computeKPIs(SAMPLE_DATA); });
    }
}

// prediction handler — safely handles server/network errors
async function handlePredict(payload) {
    try {
        const res = await fetchJSON(api.predict, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) });
        const p = Number(res.probability || 0);
        el('predLabel').innerText = res.prediction == 1 ? 'High risk (1)' : 'Low risk (0)';
        el('predProb').innerText = (p * 100).toFixed(1) + '%';
        el('modelName').innerText = res.model || 'model.pkl';
        renderGauge(p);
    } catch (e) {
        alert('Prediction failed: ' + e.message + '\n\nTip: ensure the backend is running and reachable at ' + API_BASE);
        el('predLabel').innerText = 'Error'; el('predProb').innerText = '';
    }
}

// Wire up events after DOM ready
window.addEventListener('DOMContentLoaded', () => {
    // attach form listener safely
    const form = document.getElementById('predictForm');
    form.addEventListener('submit', (ev) => {
        ev.preventDefault();
        const fd = new FormData(ev.target); const payload = {};
        fd.forEach((v, k) => payload[k] = v === '' ? null : Number(v));
        handlePredict(payload);
    });

    el('btn-load').addEventListener('click', () => loadData(100));
    el('btn-refresh').addEventListener('click', () => loadData(100));
    el('btn-clear').addEventListener('click', () => form.reset());
    el('btn-download').addEventListener('click', () => {
        if (!lastRows || lastRows.length === 0) { alert('No data loaded'); return }
        const cols = Object.keys(lastRows[0]);
        const csv = [cols.join(',')].concat(lastRows.map(r => cols.map(c => `"${String(r[c]).replace(/"/g, '""')}"`).join(','))).join('\n');
        const blob = new Blob([csv], { type: 'text/csv' }); const url = URL.createObjectURL(blob); const a = document.createElement('a'); a.href = url; a.download = 'data_preview.csv'; a.click(); URL.revokeObjectURL(url);
    });
    el('searchInput').addEventListener('input', () => { const q = el('searchInput').value.toLowerCase(); const filtered = lastRows.filter(r => Object.values(r).join(' ').toLowerCase().includes(q)); renderTable(filtered); });

    // initial load
    loadStats().catch(() => { });
    loadData(100);
});

async function loadStats() { try { const s = await fetchJSON(api.stats); if (s && s.total_rows !== undefined) el('kpi-total').innerText = (s.total_rows).toLocaleString(); if (s && s.numeric_stats && s.numeric_stats.age) el('kpi-age').innerText = Number(s.numeric_stats.age.mean).toFixed(1); } catch (e) { console.warn('stats load failed', e.message); el('kpi-total').innerText = 'n/a'; el('kpi-age').innerText = 'n/a'; } }
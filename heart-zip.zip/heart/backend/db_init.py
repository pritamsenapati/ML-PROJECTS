# backend/db_init.py
import pandas as pd
import sqlite3
import os

CSV_PATH = os.path.join(os.path.dirname(__file__), '..', 'data', 'cardiovascular_dataset_70000.csv')
DB_PATH = os.path.join(os.path.dirname(__file__), '..', 'data', 'app.db')
CLEAN_CSV_OUT = os.path.join(os.path.dirname(__file__), '..', 'data', 'clean_cardio.csv')

def clean_dataframe(df: pd.DataFrame) -> pd.DataFrame:
    # Basic cleaning tailored to your dataset
    # 1. Rename columns to lowercase
    df.columns = [c.strip().lower() for c in df.columns]

    # 2. Drop perfect duplicates
    df = df.drop_duplicates()

    # 3. Fix obvious outliers / unrealistic height/weight/ap values
    df = df[(df['height'] >= 100) & (df['height'] <= 250)]
    df = df[(df['weight'] >= 30) & (df['weight'] <= 300)]
    df = df[(df['ap_hi'] >= 50) & (df['ap_hi'] <= 250)]
    df = df[(df['ap_lo'] >= 30) & (df['ap_lo'] <= 200)]

    # 4. Ensure correct dtypes
    int_cols = ['gender','height','weight','ap_hi','ap_lo','cholesterol','gluc','smoke','alco','active','cardio']
    for c in int_cols:
        if c in df.columns:
            df[c] = pd.to_numeric(df[c], errors='coerce').round().fillna(0).astype(int)

    # 5. BMI: if missing or zero, compute from height/weight (height in cm)
    if 'bmi' in df.columns:
        df['bmi'] = pd.to_numeric(df['bmi'], errors='coerce')
        missing_bmi = df['bmi'].isna() | (df['bmi'] <= 0)
        df.loc[missing_bmi, 'bmi'] = (df.loc[missing_bmi, 'weight'] / ((df.loc[missing_bmi, 'height'] / 100) ** 2)).round(2)

    else:
        df['bmi'] = (df['weight'] / ((df['height'] / 100) ** 2)).round(2)

    # 6. Age: if age is in days convert to years heuristically (if > 120 -> probably days)
    df['age'] = pd.to_numeric(df['age'], errors='coerce')
    # if values are huge (like 10000), assume days -> convert to years
    if df['age'].max() > 200:
        df['age'] = (df['age'] / 365).round().astype(int)
    else:
        df['age'] = df['age'].round().astype(int)

    df = df.reset_index(drop=True)
    return df

def create_db():
    df = pd.read_csv(CSV_PATH)
    print("Original rows:", len(df))
    df_clean = clean_dataframe(df)
    print("Clean rows:", len(df_clean))

    # add id column
    if 'id' not in df_clean.columns:
        df_clean.insert(0, 'id', range(1, len(df_clean) + 1))

    # write cleaned csv
    df_clean.to_csv(CLEAN_CSV_OUT, index=False)
    print("Clean CSV written to", CLEAN_CSV_OUT)

    # write to sqlite
    conn = sqlite3.connect(DB_PATH)
    df_clean.to_sql('dataset', conn, if_exists='replace', index=False)
    conn.close()
    print("SQLite DB written to", DB_PATH)

if __name__ == '__main__':
    create_db()
